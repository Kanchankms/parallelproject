package com.cg.payapp.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class PayAppTest {

	@Test
	void testValidateAccount() {
		fail("Not yet implemented");
	}

	@Test
	void testValidateName() {
		fail("Not yet implemented");
	}

	@Test
	void testValidateMobileNo() {
		fail("Not yet implemented");
	}

	@Test
	void testValidateAmount() {
		fail("Not yet implemented");
	}

}

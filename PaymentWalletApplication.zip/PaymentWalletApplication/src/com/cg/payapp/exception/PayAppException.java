package com.cg.payapp.exception;

public class PayAppException extends Exception
{
	public PayAppException(String msg)
	{
		super(msg);
	}
}
